import UIKit

var myNumber = 1

myNumber = myNumber + 1
myNumber += 1

var number = 0
 
//While

while number <= 10 {
    number += 1
}


var characterAlive = true

while characterAlive == true {
    characterAlive = false
}

3 < 5
5 < 3
5 == 5
4 != 5

// For

var myFruitArray = ["Banana", "Apple","Orange"]

myFruitArray[0]
myFruitArray[1]
myFruitArray[2]

for fruit in myFruitArray{
    print(fruit)
}

var myNumbers = [10,20,30,40,50,60]

for i in myNumbers{
    print(i / 5)
}

for myNewInteger in 1 ... 5{
    print(myNewInteger * 5 )
}

