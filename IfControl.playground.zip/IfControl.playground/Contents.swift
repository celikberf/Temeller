import UIKit

var myAge = 45

if myAge < 30 {
    print("30-")
} else if myAge > 30 && myAge < 35{
    print("30s")
}else {
    print("40+")
}


