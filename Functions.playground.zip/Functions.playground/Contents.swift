import UIKit


func myFunction(){
    print("my function")
}

myFunction()

// Input & Output & Return

func sumFunction(x: Int, y:Int) -> Int{
    return x + y
}

let myFunctionVeriable = sumFunction(x: 10, y: 20)
print(myFunctionVeriable)

func logicFunction(a:Int, b:Int) -> Bool {
    if a > b {
        return true
    } else {
        return false
    }
}
 
logicFunction(a: 10, b: 20)
