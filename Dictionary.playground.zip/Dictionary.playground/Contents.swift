import UIKit

// Dictionary
// key - value pairing

var myFavoriteDirectors = ["Pulp Fiction" : "Tarantino" , "Lock Stock" : "Guy Ritchie" , "The Dark Knight" : "Chrisopher Nolan"]

myFavoriteDirectors["Pulp Fiction"]
myFavoriteDirectors["The Dark Knight"]

myFavoriteDirectors["Pulp Fiction"] = "Quentin Tarantino"

myFavoriteDirectors["Seven Samuray"] = "Akira Kurisowa"

myFavoriteDirectors

var myDictionary = ["Run" : 100 , "Swim " : 200 , "Basketball" : 300]
myDictionary["Basketball"]
