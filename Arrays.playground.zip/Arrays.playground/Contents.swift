import UIKit

var myFavoriteMovies = ["Pulp Fiction", "Kill Bill", "Reservior Dogs", 5, true] as [Any]

//as-> casting : bişeyi bişey gibi ata. herhangi bir obje dizisi gibi ata


var myStringArray = ["Test1","Test2","Test3","Test4"]

myStringArray[0].uppercased()
myStringArray.count // kaç eleman varsa gösterir
myStringArray[myStringArray.count - 2] //sondann bir önceki eleman
myStringArray.last //son elemman
myStringArray.sort() // alfabetik sıralar

var myNumberArray = [1,2,3,4,5,6,7]
myNumberArray.append(8)
myNumberArray


//Set -> indexleme yok . İçinde 1 eleman sadece 1 kez bulunabilir.
//Unordred collection unique elements

var mySet : Set = [1,2,3,4,5,1,2]
var myStringSet : Set = ["a","b","c","a"]

var myInternetArray = [1,2,3,1,2,5,6,2,1]
var myInternetSet = Set(myInternetArray)
myInternetArray
myInternetSet

var mySet1 : Set = [1,2,3]
var mySet2 : Set = [3,4,5]

var mySet3 = mySet1.union(mySet2)



